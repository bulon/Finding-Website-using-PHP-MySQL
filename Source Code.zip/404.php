<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<h2>Document not found</h2>
<a href="index.php">go to home</a>

</body>
</html>
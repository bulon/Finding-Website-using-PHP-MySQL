<?php include_once 'lib/app.php';?>
<?php include_once 'adminlogincheck.php';?>

<?php
//
//if(isset($_SESSION['user_id'])){
//
//    $id = $_SESSION['user_id'];
//    $query = "SELECT * FROM profiles WHERE user_id = $id";
//    $result = mysqli_query($link,$query);
//    $row = mysqli_fetch_assoc($result);
//
//}
?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">

            </div>

            <div class="col-lg-12 col-sm-12" style="padding-left: 0px;padding-right: 0px">
                <div class="card hovercard">
                    <div class="card-background">
                        <img class="card-bkimg" alt="" src="assets/user/uploads/dfd.jpg">
                        <!-- http://lorempixel.com/850/280/people/9/ -->
                    </div>
                    <div class="useravatar">
                        <img alt="" src="assets/user/images/admin.png">
                    </div>
                    <div class="card-info"> <span class="card-title">Admin</span>

                    </div>
                </div>

            </div>


        </div>
        <br>
        <!-- END PAGE HEAD -->
        <!-- BEGIN PAGE CONTENT -->
        <div class="page-content">
            <div class="container">
                <div class="panel panel-default">
                    <div class="panel-body text-center">

                           <div class="col-md-3">
                                <a href="usertotal.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-user"></a><p>Total users</p>
                            </div>
                            <div class="col-md-3">
                                <a href="userblock.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-remove-sign"></a><p>Block users</p>
                            </div>
                            <div class="col-md-3">
                                <a href="usersuggmanage.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-comment"></a><p>Manage suggestion</p>
                            </div>
                            <div class="col-md-3">
                                <a href="adminsettings.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-cog"></a><p>Settings</p>
                            </div>

                    </div>
                </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
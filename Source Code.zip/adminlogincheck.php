<?php
if(!isset($_SESSION['amin'])){
    header("location:login.php");
}
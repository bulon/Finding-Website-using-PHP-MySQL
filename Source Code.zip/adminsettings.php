<?php include_once 'lib/app.php';?>
<?php include_once 'adminlogincheck.php';?>
<?php
if(isset($_POST['form_logo'])) {
    $file_name = $_FILES['user_profile_pic']['name'];
    $file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
    $file_size = $_FILES['user_profile_pic']['size'];
    $upload_dir = "assets/user/images/";
    $file_ext = substr($file_name, strripos($file_name, '.')); // Extract extension
    if (($file_ext != '.png') && ($file_ext != '.PNG')) {
        $error_meassage= "Only png format is supported!";

    } else {
        $f1 = "logo".$file_ext;
        move_uploaded_file($file_tmp_name, "$upload_dir" . $f1) or die("<span style='color: red'>Upload Failed!</span><br>");
        $query ="UPDATE `lostnfound`.`theme_option` SET `logo` = '".$f1."' WHERE `theme_option`.`id` = 1";
        $result = mysqli_query($link,$query);
        if($result){
            $success_message = "Successfully changed!";
        }else{
            $error_meassage= "Ops Failed!";
        }



    }
}
?>

<?php
if(isset($_POST['form_footer_text'])){
    $text = $_POST['footer_text'];
    if(empty($text)){
        $error_meassage= "Please write footer text";
    }else{
        $query ="UPDATE `lostnfound`.`theme_option` SET `fotter_text` = '".$text."' WHERE `theme_option`.`id` = 1";
        $result = mysqli_query($link,$query);
        if($result){
            $success_message = "Successfully changed!";
        }else{
            $error_meassage= "Ops Failed!";
        }
    }
}

?>
<?php
if(isset($_POST['form_admin'])){
    $file_name = $_FILES['user_profile_pic']['name'];
    $file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
    $file_size = $_FILES['user_profile_pic']['size'];
    $upload_dir = "assets/user/images/";
    $title = $_POST['gd_title'];
    $des = $_POST['gd_des'];
    $modified = date("d-m-y h:i:s");
if(empty($file_name)) {
    $query = "UPDATE `lostnfound`.`guidelines` SET `title` = '" . $title . "', `description` = '" . $des . "',
`modified` = '" . $modified . "' WHERE `guidelines`.`id` = 1 ";
    $result = mysqli_query($link,$query);
    if($result){
        $success_message = "Successfully updated";
    }else{
        $error_meassage ="Update failed";
    }


 }else{
    $file_ext = substr($file_name, strripos($file_name, '.'));

    if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
        echo "Only jpg, jpeg, png and gif format images are allowed to upload.";

    }else{
        $query = "SELECT * FROM guidelines ";
        $result = mysqli_query($link,$query);
        $row = mysqli_fetch_array($result);
        $real_path = $upload_dir.$row['example'];
        unlink($real_path);
        $captcha ="";
        for($i=0;$i<=10;$i++){


            $captcha .= chr(rand(97,122));


        }
        $f1 = $captcha.$file_name;
        move_uploaded_file($file_tmp_name,"$upload_dir".$f1) or die("<span style='color: red'>Upload Failed!</span><br>");
        $query = "UPDATE `lostnfound`.`guidelines` SET `title` = '" . $title . "', `description` = '" . $des . "', `example` = '" . $f1 . "',
`modified` = '" . $modified . "' WHERE `guidelines`.`id` = 1 ";
        $result = mysqli_query($link,$query);
        if($result){
            $success_message = "Successfully updated";
        }else{
            $error_meassage ="Update failed";
        }


    }






}
}


?>
<?php
//
//if(isset($_SESSION['user_id'])){
//
//    $id = $_SESSION['user_id'];
//    $query = "SELECT * FROM profiles WHERE user_id = $id";
//    $result = mysqli_query($link,$query);
//    $row = mysqli_fetch_assoc($result);
//
//}
?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>


</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">

            </div>

            <div class="col-lg-12 col-sm-12">
                <div class="card hovercard">
                    <div class="card-background">
                        <img class="card-bkimg" alt="" src="assets/user/uploads/dfd.jpg">
                        <!-- http://lorempixel.com/850/280/people/9/ -->
                    </div>
                    <div class="useravatar">
                        <img alt="" src="assets/user/images/admin.png">
                    </div>
                    <div class="card-info"> <span class="card-title">Admin</span>

                    </div>
                </div>
                <?php
                if(isset($error_meassage))
                {
                    echo '<div class="alert alert-danger">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Ops ! &nbsp;</strong>';
                    echo $error_meassage."<br>";
                    echo '</div>';
                }
                if(isset($success_message))
                {
                    echo '<div class="alert alert-success">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Nice! &nbsp;</strong>';
                    echo $success_message."<br>";
                    echo '</div>';
                }
                ?>

            </div>


        </div>
        <br>
        <!-- END PAGE HEAD -->
        <!-- BEGIN PAGE CONTENT -->
        <div class="page-content">
            <div class="container">
                <div class="panel panel-default">
                    <div class="panel-body text-center">

                        <div class="col-md-3">
                            <a href="" data-toggle="modal" data-target="#myModal" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-leaf"></a><p>Change logo</p>
                            <!-- Change logo -->
                            <div class="modal fade text-left " id="myModal" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Change your logo here</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="adminsettings.php" class="form-horizontal" role="form" enctype="multipart/form-data">

                                                <div class="form-group">
                                                    <label class="control-label col-sm-2" for="pwd">Logo</label>
                                                    <div class="col-sm-10">
                                                        <input type="file" style="height: auto" class="form-control" name="user_profile_pic" id="pwd" >
                                                        <p>Logo should be png format and best size is 130 x 30 px</p>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-sm-offset-2 col-sm-10">
                                                        <button type="submit" name="form_logo" class="btn btn-default">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a href="" data-toggle="modal" data-target="#footerText" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-text-background"></a><p>Change footer text</p>
                            <!-- footer text -->
                            <div class="modal fade text-left " id="footerText" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Change footer text</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="adminsettings.php" class="form-horizontal" role="form" enctype="multipart/form-data">

                                                <div class="form-group">
                                                    <label class="control-label col-sm-2" for="pwd">Footer text</label>
                                                    <div class="col-sm-10">
                                                        <?php
                                                        $footer_query ="select * from theme_option";
                                                        $footer_result =mysqli_query($link,$footer_query);
                                                        $row = mysqli_fetch_array($footer_result);

                                                        ?>
                                                        <input type="text" value="<?php echo $row['fotter_text'];?>" class="form-control" name="footer_text" id="pwd" >

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-sm-offset-2 col-sm-10">
                                                        <button type="submit" name="form_footer_text" class="btn btn-default">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <a href="" data-toggle="modal" data-target="#guideLines" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-flag"></a><p>Guidelines settings</p>
                            <div class="modal fade text-left " id="guideLines" role="dialog">
                                <div class="modal-dialog">
                                    <?php
                                    $query = "SELECT * FROM guidelines ";
                                    $result = mysqli_query($link,$query);
                                    $row = mysqli_fetch_array($result);

                                    ?>

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Update guidelines information</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="panel panel-default">
                                                <div class="panel-heading"><span class="glyphicon glyphicon-flag"></span> Update Guidelines</div>
                                                <div class="panel-body">
                                                    <form method="post" action="adminsettings.php" class="form-horizontal" role="form" enctype="multipart/form-data">

                                                        <div class="form-group">
                                                            <label class="control-label col-sm-2" for="pwd">Title</label>
                                                            <div class="col-sm-10">
                                                                <input type="text" style="height: auto" value="<?php echo $row['title'];?>" class="form-control" name="gd_title" id="pwd" >
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-sm-2" for="pwd">Description</label>
                                                            <div class="col-sm-10">
                                                                <textarea id="pwd" name="gd_des" class="form-control"><?php echo $row['description'];?></textarea>

                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-sm-2" for="pwd">Example</label>
                                                            <div class="col-sm-10">
                                                                <input type="file" style="height: auto" class="form-control" name="user_profile_pic" id="pwd" >
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-offset-2 col-sm-10">
                                                                <button type="submit" name="form_admin" class="btn btn-default">Submit</button>
                                                            </div>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <!-- END PAGE CONTENT -->
    </div>
    <!---Page Content End--->


    <!---Page Footer Begin--->
    <?php include_once('page_footer.php'); ?>
    <!---Page Footer End--->
<html>
<head></head>
<body>
<div style='border: 1px solid #000000;padding: 5px;text-align: center;width: 450px;box-shadow: 0px 0px 5px #000'>
    <img src='assets/user/images/logo.png'>
    <p>To found the owner of this product</p>
    <P>please visit the website: www.lostnfound.com</P>
    <p>Code: <code style='color: #58b8a9'>$code</code></p>
    <P>Thank you for with us</P>
</div>
</body>
</html>
<?php include_once 'lib/app.php';?>





<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu_unregistered.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">

            </div>
<!--
            <div class="row">
                <div class="col-md-12">
                    <div class="list-group text-center">
                        <a class="list-group-item " href="#"><i class="fa fa-home fa-fw"></i>&nbsp; User profile</a>
                        <a class="list-group-item" href="#"><i class="fa fa-cog fa-fw"></i>&nbsp; Edit profile</a>
                        <a class="list-group-item" href="#"><i class="fa fa-cog fa-fw"></i>&nbsp; Settings</a>
                        <a class="list-group-item" href="#"><i class="fa fa-book fa-fw"></i>&nbsp; Product registration</a>
                        <a class="list-group-item" href="#"><i class="fa fa-pencil fa-fw"></i>&nbsp; Existing Products</a>
                    </div>

                </div>
            </div>


-->

            


    </div>
<br>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">
            <div class="panel panel-default">

                <div class="panel-body text-center">

                    <div class="col-md-3">
                        <a href="productaddwithoutcode.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-shopping-cart"></a><p>Add product</p>
                    </div>
                    <div class="col-md-3">
                        <a href="productmanagewithoutregistration.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-pencil"></a><p>Product List</p>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<title>Lost and Found</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	
		<link rel="icon" type="image/png" href="favicon.png"> 
  
		<link rel="stylesheet" href="assets/global/css/font-awesome.min.css" media="all" />   <!-- Font awesome css -->
		<link rel="stylesheet" href="assets/global/css/bootstrap.min.css"/>  					<!-- Bootstrap -->		
		<link rel="stylesheet" href="assets/global/css/reset.css"/>
        <!-- Recet css -->
        <?php $str =rand(1,2);?>
		<link rel="stylesheet" href="assets/global/css/style<?php echo $str;?>.css"/>							<!-- Style css -->
		<link rel="stylesheet" href="assets/global/css/responsive.css" media="all" />			<!-- Responsive css -->
		<link rel="stylesheet" href="assets/global/css/preloder.css" media="all" />			<!-- Preloder css -->
	<!--[if lt IE 8]><link rel="stylesheet" href="assets/blueprint-css/ie.css" type="text/css" media="screen, projection"><![endif]-->
	</head>
	<body>
		<!-- loader-wrapper -->		
		<div id="loader-wrapper">
			<div id="loader"></div>
			<div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
		</div>
		<!-- end loader-wrapper -->	
		<!-- canvas -->			
		<div id="canvas-holder">
			<canvas id="demo-canvas"></canvas>
		</div>
		<!--end canvas -->


		
		<div id="main">  <!--start main div -->
		
<!--

				
<!--
## HOME area  Welcome to our website
=============================================================================== -->	
	
			<div class="home_area"> <!-- Home area-->
				<div class="container">
					<div class="row"><br><br>
						<div class="col-sm-12">
							<div class="logo">
								<a href="index.php"><img src="assets/user/images/logo.png" alt="logo" /></a> <!-- Here is your logo -->
							</div>


						</div>
					</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="home_area_text">
								<h2>Lost and found directory</h2> <!-- Page title -->
								<h4>Search your code to know lost product details</h4>
							</div>
						</div>
					</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
					
						</div>
					</div>
				</div>	
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="subscribe_area"> <!-- Subscribe -->
								<!-- form section -->	
								<form  method="post" action="searchprocess.php">
									<input class="email_input subscribe" name="code" type="text" placeholder="Enter Your code">
									<button class="email_submit" name = "form" type="submit"><i class="fa fa-camera-search-plus"></i> Search</button>

								</form>
								<!-- end form section -->

							</div>
                            <br>

                            <a href="signup.php" class="btn btn-default">Register</a> <a href="login.php" class="btn btn-default">Sign-in</a> <a href="foundproduct.php" class="btn btn-default">Product</a>
						</div>
					</div>
				</div>
			
			</div>	<!-- //Home area-->
			
</div>
			
<!--
##  javascript All file include
=============================================================================== -->			
		
		<script src="assets/global/scripts/jquery-1.9.1.min.js"></script>	              	<!-- Main js file -->
		<script src="assets/global/scripts/custom.js"></script>						   	<!-- Custom js file -->	
		<script src="assets/global/scripts/bootstrap.min.js"></script>						<!-- Bootstrap js file -->
		<script src="assets/global/scripts/canvas.js"></script>     						<!-- canvas js file -->  	
		
	</body>
</html>
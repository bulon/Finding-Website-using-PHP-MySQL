<?php include_once 'authorization_check.php';?>
<div class="page-header-top">
    <div class="container">
        <!-- BEGIN LOGO -->
        <div class="page-logo">
            <a href="index.php"><img src="assets/user/images/logo.png"" alt="logo" class="logo-default"></a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN RESPONSIVE MENU TOGGLER -->
        <a href="javascript:;" class="menu-toggler"></a>
        <!-- END RESPONSIVE MENU TOGGLER -->


        <!-- BEGIN TOP NAVIGATION MENU -->
        <!--Here code is in page header.txt--->

        <!-- END TOP NAVIGATION MENU -->


    </div>
</div>
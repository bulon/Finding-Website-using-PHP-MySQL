<?php include_once 'authorization_check.php';?>
<?php
if(isset($_SESSION['user'])){
    include_once('page_menu_user.php');
}
else{

    include_once('page_menu_admin.php');
}

?>
<?php include_once 'authorization_check.php';?>
<div class="page-header-menu">
    <div class="container">
        <!-- BEGIN HEADER SEARCH BOX -->
        <form class="search-form" action="searchprocess.php" method="post">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search" name="code">
					<span class="input-group-btn">
					<a href="javascript:;" class="btn submit"><i class="icon-magnifier"></i></a>
					</span>
            </div>
        </form>
        <!-- END HEADER SEARCH BOX -->
        <!-- BEGIN MEGA MENU -->
        <!-- DOC: Apply "hor-menu-light" class after the "hor-menu" class below to have a horizontal menu with white background -->
        <!-- DOC: Remove data-hover="dropdown" and data-close-others="true" attributes below to disable the dropdown opening on mouse hover -->
        <div class="hor-menu ">
            <ul class="nav navbar-nav">
                <li>
                    <a href="index.php">Home</a>
                </li>

                <li>
                    <a href="userguidelines.php">Help</a>
                </li>


            </ul>
        </div>
        <!-- END MEGA MENU -->
    </div>
</div>
<?php include_once 'lib/app.php';?>
<?php include_once 'userlogincheck.php';?>
<?php
if(isset($_SESSION['user_id'])){

$id = $_SESSION['user_id'];

}
?>
<?php
if(isset($_POST['form1'])){

    try{

        $title = test_input($_POST['product_title']);
        $description = test_input($_POST['product_description']);


        // Unique Product Code Generate Starts
        function random_string($length) {
            $key = '';
            $keys = array_merge(range(0, 9), range('A', 'Z'));

            for ($i = 0; $i < $length; $i++) {
                $key .= $keys[array_rand($keys)];
            }

            return $key;
        }


        function isUnique(){

            global $product_code;
            $product_code=random_string(6);
            $query="SELECT product_code FROM products WHERE product_code='$product_code'";
            $result = mysqli_query($link,$query);

            $row = mysqli_fetch_assoc($result);


        }

        $uniq_result=isUnique();

        if(!empty($uniq_result) && isset($uniq_result)){

            header('Location: '.$_SERVER['PHP_SELF']);

        }

// Unique Product Code Generate Ends

        $user_id = $id;

        $file_name = $_FILES['user_profile_pic']['name'];
        $file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
        $file_size = $_FILES['user_profile_pic']['size'];
        $upload_dir = "assets/user/products/";



        $error =0;
        $msg ='';
        if(empty($title)){

           $error =1;
            $msg .= "<p>Product title is empty!</p>";

        }

        if(empty($description)){

            $error =1;
            $msg .= "<p>Product description is empty!</p>";

        }
        if(empty($file_tmp_name)){

            $error =1;
            $msg .= "<p>You did not select any image!</p>";

        }

        if($error == 1){
            throw new exception($msg);
        }


        $file_ext = substr($file_name, strripos($file_name, '.')); // Extract extension
        if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
            throw new exception("Only jpg, jpeg, png and gif format images are allowed to upload.");

        }else {

            $rand = rand(10000,999999);
            $f1 = $rand . $file_name;
            move_uploaded_file($file_tmp_name, "$upload_dir" . $f1) or die("<span style='color: red'>Upload Failed!</span><br>");

            $query = "INSERT INTO `lostnfound`.`products` (`id`, `title`, `description`, `product_code`, `user_id`,
 `product_picture`) VALUES (NULL, '".$title."', '".$description."', '".$product_code."', '".$user_id."', '".$f1."')";

            $result = mysqli_query($link,$query);
            if($result){
                header("location:productcode.php?code= $product_code");

            }else{
                throw new exception("Registration process faield");
            }





        }

    }

    catch(Exception $e){

        $error_meassage = $e->getMessage();



    }




}



?>

<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Add Product <small>Fill up the Product details</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-sign-in"></i> Sign up</div>
                <div class="panel-body">

                    <?php
                    if(isset($error_meassage))
                    {
                        echo '<div class="alert alert-danger">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Ops ! &nbsp;</strong>';
                        echo $error_meassage."<br>";
                        echo '</div>';
                    }

                    if(isset($success_message))
                    {
                        echo '<div class="alert alert-success">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Nice! &nbsp;</strong>';
                        echo $success_message."<br>";
                        echo '</div>';
                    }
                    ?>

                    <form action="" method="post" enctype="multipart/form-data">



                        <div class="form-group">
                            <label class="control-label col-md-2" for="title">Product title</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="title" name="product_title" placeholder="Product itle">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="description">Product descripttion</label>
                            <div class="col-md-10">
                                <textarea class="form-control" id="description" name="product_description" placeholder="Product descripttion"> </textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="profilePic">Product Picture</label>
                            <div class="col-md-10">
                                <input type="file" style="height: auto" class="form-control" id="profilePic" name="user_profile_pic" >
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-md-offset-2 col-md-10">
                                <button type="submit" name ="form1" class="btn btn-default"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Submit</button>
                            </div>
                        </div>


                    </form>

                </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
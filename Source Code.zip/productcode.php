<?php include_once 'lib/app.php';

?>

<?php include_once 'userlogincheck.php';

?>
<?php
$code = $_REQUEST['code'];
$_SESSION['barcode'] = $code;

?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">

            </div>




        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">


            <div class=" text-center">
                <div id="divid">
                    <img src='assets/user/images/logo.png'>

                    <p>To found the owner of this product</p>
                    <P>please visit the website: <a href="https://www.lostnfound.com"> www.lostnfound.com</a></P>
<!--                    <div  style="margin: auto;width: 100"> --><?php //echo bar128($code)?><!--</div>-->
                    <p><img src="http://qrickit.com/api/qr?d=To found the owner of this product 

please visit the website: www.lostnfound.com. Code :<?php echo $code; ?>"></p>
                    <img src="test.php">
                    
                    <p>Code: <code style='color: #58b8a9'><?php echo $code;?></code></p>
                    <P>Thank you for with us</P>
                </div>

                <a  class="btn btn-sm btn-danger" name="btnprint" value="Print" onclick="PrintMe('divid')" ><span class="glyphicon glyphicon-print"></span> Print</a>
                <a  class="btn btn-sm btn-danger"  href="productcodedownload.php?code=<?php echo $code ;?>"><span class="glyphicon glyphicon-file"></span> PDF</a>

            </div>



        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>

<!---Page Footer End--->
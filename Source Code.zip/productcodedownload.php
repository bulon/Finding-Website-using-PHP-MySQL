<?php include_once 'lib/app.php';?>
<?php
if(isset($_REQUEST['code'])){
    $code =$_REQUEST['code'];
    $_SESSION['barcode'] =$code;
    require_once("lib/dompdf/dompdf_config.inc.php");
    spl_autoload_register('DOMPDF_autoload');
    $filename = 'lostnfound-'.$code;
    $dompdf = new DOMPDF();
  //$html = file_get_contents('file_html.php');
    $html = "
<html>
   <head></head>
   <body>
        <div style='border: 1px solid #000000;padding: 5px;text-align: center;width: 450px;box-shadow: 0px 0px 5px #000'>
        <img src='assets/user/images/logo.png'>
        <p>To found the owner of this product</p>
       <P>please visit the website: www.lostnfound.com</P>
       <p>Code: <code style='color: #58b8a9'>$code</code></p>
        <P>Thank you for with us</P>
        </div>
   </body>
</html>
";


    pdf_create($html,$filename,'A4','portrait');
}
header('location:productmanage.php');
?>
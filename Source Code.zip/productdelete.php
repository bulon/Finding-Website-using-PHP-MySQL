<?php include_once 'lib/app.php';?>
<?php include_once 'userlogincheck.php';?>

<?php
if(isset($_REQUEST['id'])){
    $id= $_REQUEST['id'];
    $query1 = "SELECT product_picture FROM products WHERE `id` = '$id' ";
    $result1 = mysqli_query($link,$query1);
    $row = mysqli_fetch_array($result1);
    $real_path = "assets/user/products/".$row['product_picture'];
    unlink($real_path);
    $query ="DELETE FROM products WHERE id='$id'";
    $result = mysqli_query($link,$query);



    header("location:productmanage.php");

}else{
    header("location:productmanage.php");
}

?>
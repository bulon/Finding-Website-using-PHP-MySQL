<?php include_once 'lib/app.php';?>
<?php include_once 'userlogincheck.php';?>
<?php
if(isset($_POST['form'])){
    $id = $_REQUEST['id'];
    $title = test_input($_POST['product_title']);
    $description = test_input($_POST['product_description']);
    $file_name = $_FILES['user_profile_pic']['name'];
    $file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
    $file_size = $_FILES['user_profile_pic']['size'];
    $upload_dir = "assets/user/products/";

    if(empty($file_name)){

        $query = "UPDATE `lostnfound`.`products` SET `title` = '".$title."', `description` = '".$description."' WHERE `products`.`id` = '$id';";
        $result = mysqli_query($link,$query);



    }else{


        $file_ext = substr($file_name, strripos($file_name, '.')); // Extract extension

        if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
            echo "Only jpg, jpeg, png and gif format images are allowed to upload.";

        }
        else{


            $query = "SELECT product_picture FROM products WHERE id = '$id' ";
            $result = mysqli_query($link,$query);
            $row = mysqli_fetch_array($result);
            $real_path = "assets/user/products/".$row['product_picture'];
            unlink($real_path);
            $captcha ="";
            for($i=0;$i<=10;$i++){


                $captcha .= chr(rand(97,122));


            }
            $f1 = $captcha.$file_name;
            move_uploaded_file($file_tmp_name,"$upload_dir".$f1) or die("<span style='color: red'>Upload Failed!</span><br>");
            $query = "UPDATE `lostnfound`.`products` SET `title` = '".$title."', `description` = '".$description."',`product_picture`='".$f1."' WHERE `products`.`id` = '$id';";
            $result = mysqli_query($link,$query);


        }

    }

}

?>

<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>User Profile <small>Manage your user profile</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <table class="table table-bordered">
                <thead>
                <tr>

                    <th>Sl</th>
                    <th>Product title</th>
                    <th>Product description</th>
                    <th>Product code</th>
                    <th>Picture</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php

                $query ="select * FROM products WHERE user_id='$_SESSION[user_id]' ";
                $result = mysqli_query($link,$query);

                $i=0;

                while($row = mysqli_fetch_array($result)){
                    $i++;


                    ?>

                    <tr>

                        <td><?php echo $i;?></td>
                        <td><?php echo $row['title'];?></td>
                        <td><?php echo $row['description'];?></td>
                        <td><?php echo $row['product_code'];?></td>
                        <td><img  class="img-thumbnail" width="50" height="50" src="assets/user/products/<?php echo $row['product_picture'];?>"</td>
                        <td>
                            <a data-toggle="modal" data-target="#myModal<?php echo $i; ?>" href="" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-pencil"></span></a>
                            <!-- Modal -->
                            <div class="modal fade" id="myModal<?php echo $i; ?>" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Update your product information</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="panel panel-default">
                                                <div class="panel-heading"><i class="fa fa-sign-in"></i> Edit product info </div>
                                                <div class="panel-body">



                                                    <form action="productmanage.php?id=<?php echo $row['id'];?>" method="post" enctype="multipart/form-data">



                                                        <div class="form-group">
                                                            <label class="control-label col-md-2" for="title">Title</label>
                                                            <div class="col-md-10">
                                                                <input type="text" value="<?php echo $row['title'];?>" class="form-control" id="title" name="product_title" placeholder="Product itle">
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="control-label col-md-2" for="description">Descripttion</label>
                                                            <div class="col-md-10">
                                                                <textarea class="form-control" id="description" name="product_description" placeholder="Product descripttion"><?php echo $row['description'];?> </textarea>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="control-label col-md-2" for="profilePic">Picture</label>
                                                            <div class="col-md-10">
                                                                <input type="file" style="height: auto" class="form-control" id="profilePic" name="user_profile_pic" >
                                                            </div>
                                                        </div>


                                                        <div class="form-group">
                                                            <div class="col-md-offset-2 col-md-10">
                                                                <button type="submit" name ="form" class="btn btn-default"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Submit</button>
                                                            </div>
                                                        </div>


                                                    </form>

                                                </div>
                                            </div>



                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <a data-toggle="modal" href="productdelete.php?id=<?php echo $row['id'];?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-remove"></span></a>

                            <a  class="btn btn-sm btn-primary"  href="productcodedownload.php?code=<?php echo $row['product_code'];?>"><span class="glyphicon glyphicon-file"></span></a>


                        </td>


                    </tr>



                <?php
                }

                ?>


                </tbody>
            </table>



        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
<?php include_once 'lib/app.php';?>
<?php
if(isset($_POST['form'])){
    $id = $_REQUEST['id'];
    $title = test_input($_POST['product_title']);
    $description = test_input($_POST['product_description']);
    $file_name = $_FILES['user_profile_pic']['name'];
    $file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
    $file_size = $_FILES['user_profile_pic']['size'];
    $upload_dir = "assets/user/products/";

    if(empty($file_name)){

        $query = "UPDATE `lostnfound`.`products` SET `title` = '".$title."', `description` = '".$description."' WHERE `products`.`id` = '$id';";
        $result = mysqli_query($link,$query);



    }else{


        $file_ext = substr($file_name, strripos($file_name, '.')); // Extract extension

        if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
            echo "Only jpg, jpeg, png and gif format images are allowed to upload.";

        }
        else{


            $query = "SELECT product_picture FROM products WHERE id = '$id' ";
            $result = mysqli_query($link,$query);
            $row = mysqli_fetch_array($result);
            $real_path = "assets/user/products/".$row['product_picture'];
            unlink($real_path);
            $captcha ="";
            for($i=0;$i<=10;$i++){


                $captcha .= chr(rand(97,122));


            }
            $f1 = $captcha.$file_name;
            move_uploaded_file($file_tmp_name,"$upload_dir".$f1) or die("<span style='color: red'>Upload Failed!</span><br>");
            $query = "UPDATE `lostnfound`.`products` SET `title` = '".$title."', `description` = '".$description."',`product_picture`='".$f1."' WHERE `products`.`id` = '$id';";
            $result = mysqli_query($link,$query);


        }

    }

}

?>

<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu_unregistered.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>User Profile <small>Manage your user profile</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <table class="table table-bordered">
                <thead>
                <tr>

                    <th>Sl</th>
                    <th>Product title</th>
                    <th>Founders Address</th>

                    <th>Picture</th>
                </tr>
                </thead>
                <tbody>
                <?php

                $query ="select * FROM found";
                $result = mysqli_query($link,$query);

                $i=0;

                while($row = mysqli_fetch_array($result)){
                    $i++;


                    ?>

                    <tr>

                        <td><?php echo $i;?></td>
                        <td><?php echo $row['title'];?></td>
                        <td><?php echo $row['description'];?></td>
                        <td><img  class="img-thumbnail" width="50" height="50" src="assets/user/products/<?php echo $row['product_picture'];?>"</td>
                        


                    </tr>



                <?php
                }

                ?>


                </tbody>
            </table>



        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
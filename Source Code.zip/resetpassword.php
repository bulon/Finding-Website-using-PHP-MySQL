<?php include_once 'lib/app.php';?>
<?php
if(isset($_REQUEST['codegen'])){
    $email = $_REQUEST['email'];
    $new_password_gen = unique_id_gen();
    $new_password = md5($new_password_gen);
    $query ="UPDATE `lostnfound`.`users` SET `password` = '".$new_password."' WHERE `users`.`email` = '$email'";
    if($result){
        $success_message = "Successfully changed! please change your password from your dashboard <a href='login.php'>Login now</a>";
    }else{
        $error_meassage= "Ops Failed! <a href='login.php'>Try again</a>";
    }

}
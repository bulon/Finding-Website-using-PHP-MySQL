<?php
include_once 'lib/app.php';

ob_start();

?>


<?php



    if(isset($_POST['form']))
    {






            $code = test_input($_POST['code']);

            $query = "SELECT * FROM `products` WHERE product_code = '$code'";

            $result = mysqli_query($link,$query);


            $search_result = mysqli_fetch_assoc($result);

//                                $_SESSION['product_results'] = $search_result;

            //debug($search_result);

             $user_id = $search_result['user_id'];

             $product_code=$search_result['product_code'];

			
			//echo $user_id;

//                                $query2 = "SELECT * FROM profiles WHERE user_id= '$user_id ' ";
//                                $result2 = mysqli_query($link,$query2);
//                                
//                                
//                                $user_profile_results = mysqli_fetch_assoc($result2);
//                                
            if(isset($user_id) && !empty($user_id)){
                $_SESSION['user_id']=$user_id;
                $_SESSION['product_code']=$product_code;

            header("location:searchresult.php");
            }else{
				$_SESSION['wrong_code'] = '11';
               header("location:wrongcode.php");
            }






    }else{
        header('location:index.php');
    }

?>







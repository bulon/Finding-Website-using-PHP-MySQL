<?php include_once 'lib/app.php';?>
<?php
if(isset($_SESSION['user_id']) && isset($_SESSION['product_code'])){


    $user_id=$_SESSION['user_id'];
    $product_code=$_SESSION['product_code'];

    $query = "SELECT * FROM profiles,products WHERE profiles.user_id= '$user_id ' and products.product_code='$product_code' and profiles.user_id=products.user_id ";
    $result = mysqli_query($link,$query);

    $user_results = mysqli_fetch_assoc($result);

    unset($_SESSION['user_id']);
    unset($_SESSION['product_code']);

}else{
    header('location:index.php');

}

                                
            

?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu_u_user.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
	<!-- BEGIN PAGE HEAD -->
	<div class="page-head">
		<div class="container">
			<!-- BEGIN PAGE TITLE -->
			<div class="page-title">
				<h1>Dashboard <small>Product Owner's Information</small></h1>
			</div>


			<!-- END PAGE TITLE -->

		</div>
	</div>
	<!-- END PAGE HEAD -->
	<!-- BEGIN PAGE CONTENT -->
	<div class="page-content">
		<div class="container">
                    <div class="panel panel-default">
                        <div class="panel-heading">Details information</div>
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <h1>Personal Information</h1>
                                    <div class="col-md-9 p_result_div">
                                        <p><label>Name  </label>:<span><?php echo $user_results['first_name']." ".$user_results['last_name']; ?></span></p>
                                        <p><label>Address</label>:<span><?php echo $user_results['address']; ?></span></p>
                                        <p><label>Zip Code</label>:<span><?php echo $user_results['zip_code']; ?></span></p>
                                        <p><label>City</label>:<span><?php echo $user_results['city']; ?></span></p>
                                        <p><label>District</label>:<span><?php echo $user_results['district']; ?></span></p>
                                        <p><label>Mobile/Phone</label>:<span><?php echo $user_results['mobile_number']; ?></span></p>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo "assets/user/uploads/".$user_results['profile_picture']; ?>" alt="" class="img-thumbnail" height="300" width="300">
                                        
                                    </div>
                                    
                                </div>
                                
                                <div class="col-md-12">
                                    <h1>Product Information</h1>
                                    <div class="col-md-9  p_result_div">
                                        <p><label>Product Code</label>:<span><?php echo $user_results['product_code']; ?></span></p>
                                        <p><label>Product Title</label>:<span><?php echo $user_results['title']; ?></span></p>
                                        <p><label>Product Description</label>:<span><?php echo $user_results['description']; ?></span></p>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo "assets/user/products/".$user_results['product_picture']; ?>" alt="" class="img-thumbnail" height="300" width="300">
                                    </div>
                                </div>
                                
                                
                            </div>
                            
                            
                            
                        </div>
                    </div>
                    
                    
                    

		</div>
	</div>
	<!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
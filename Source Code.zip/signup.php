<?php include_once 'lib/app.php';?>

<?php
$opt_user_fname='';
$opt_user_lname='';
$opt_user_name='';
$opt_user_password='';
$opt_user_email='';
$opt_user_mobile='';
$opt_user_address='';
$opt_user_zipcode='';
$opt_user_city='';
$opt_user_district='';

if(isset($_POST['form1'])){



    $user_id_track ="";
    for($i=0;$i<=5;$i++){


        $user_id_track .= (rand(0,9));


    }

    $user_id = $user_id_track;



    $user_name = test_input($_POST['username']);
    $user_fname = test_input($_POST['user_first_name']);
    $user_lname = test_input($_POST['user_last_name']);
    $user_fullname = $user_fname.' '.$user_lname;
    $user_password = md5(test_input($_POST['user_password']));
    $user_email = test_input($_POST['user_email']);
    $user_mobile = test_input($_POST['user_mobile']);
    $user_address = test_input($_POST['user_address']);
    $user_zipcode = test_input($_POST['user_zipcode']);
    $user_city = test_input($_POST['user_city']);
    $user_district = test_input($_POST['user_district']);
    $user_captcha = test_input($_POST['user_captcha']);
    $status =1;

   $created_date = date("Y-m-d h:i:s");
    $created_by = $user_id;

    $file_name = $_FILES['user_profile_pic']['name'];
    $file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
    $file_size = $_FILES['user_profile_pic']['size'];
    $upload_dir = "assets/user/uploads/";

    try{



        $error =0;
        $msg ='';
        if(empty($user_id)){

            $error =1;
            $msg = "<p>User id can not be empty!</p>";

        }


		

        if(empty($user_fname)){

            $error =1;
            $msg .= "<p>First name empty!</p>";

        }else{
            $_SESSION['user_fname']=$user_fname;
            if(isset($_SESSION['user_fname'])){
                $opt_user_fname="value='$user_fname'";
            }
        }
        if(empty($user_lname)){

            $error =1;
            $msg .= "<p>Last empty!</p>";

        }else{
            $_SESSION['user_lname']=$user_lname;
            if(isset($_SESSION['user_lname'])){
                $opt_user_lname="value='$user_lname'";
            }
        }
        if(empty($user_name)){

            $error =1;
            $msg .= "<p>User name can not be empty!</p>";


        }else{
            $query5="SELECT * FROM users WHERE username='$user_name'";
            $result5=mysqli_query($link,$query5);
            $row5=mysqli_fetch_assoc($result5);
            if(mysqli_num_rows($result5)>=1){
                $error =1;
                $msg .= "<p>This username is already exist. Please change the username !</p>";


            }
            $_SESSION['user_name']=$user_name;
            if(isset($_SESSION['user_name'])){
                $opt_user_name="value='$user_name'";
            }
        }

        if(empty($user_password)){

            $error =1;
            $msg .= "<p>Password is empty!</p>";

        }else{
            $_SESSION['user_password']=$user_password;
            if(isset($_SESSION['user_password'])){
                $opt_user_password="value='$user_password'";
            }
        }
        if(empty($user_email)){

            $error =1;
            $msg .= "<p>Email is empty!</p>";

        }else{
            $query6="SELECT * FROM users WHERE email='$user_email'";
            $result6=mysqli_query($link,$query6);
            $row6=mysqli_fetch_assoc($result6);
            if(mysqli_num_rows($result6)>=1){
                $error =1;
                $msg .= "<p>This Email is already exist. Please change the Email !</p>";

            }
            $_SESSION['user_email_c']=$user_email;
            if(isset($_SESSION['user_email_c'])){
                $opt_user_email="value='$user_email'";
            }
        }

        if(empty($user_mobile)){

            $error =1;
            $msg .= "<p>Mobile number is empty!</p>";

        }else{
            $_SESSION['user_mobile_n']=$user_mobile;
            if(isset($_SESSION['user_mobile_n'])){
                $opt_user_mobile="value='$user_mobile'";
            }
        }
        if(empty($user_address)){

            $error =1;
            $msg .= "<p>Address is empty!</p>";

        }else{
            $_SESSION['user_address']=$user_address;
            if(isset($_SESSION['user_address'])){
                $opt_user_address="value='$user_address'";
            }
        }
        if(empty($user_zipcode)){

            $error =1;
            $msg .= "<p>Zip code is empty!</p>";

        }else{
            $_SESSION['user_zipcode_u']=$user_zipcode;
            if(isset($_SESSION['user_zipcode_u'])){
                $opt_user_zipcode="value='$user_zipcode'";
            }
        }
        if(empty($user_city)){

            $error =1;
            $msg .= "<p>City is not filled!</p>";

        }else{
            $_SESSION['user_city_u']=$user_city;
            if(isset($_SESSION['user_city_u'])){
                $opt_user_city="value='$user_city'";
            }
        }

        if(empty($user_district)){

            $error =1;
            $msg .= "<p>District is not mentioned!</p>";

        }else{
            $_SESSION['user_district']=$user_district;
            if(isset($_SESSION['user_district'])){
                $opt_user_district="value='$user_district'";
            }
        }
        if(empty($user_captcha)){

            $error =1;
            $msg .= "<p>You must fill your captcha</p>";

        }
        if(empty($file_name)){

            $error =1;
            $msg .= "<p>Your Pic not selected!</p>";

        }

        if($error == 1){
            throw new exception($msg);
        }

        if($user_captcha != $_SESSION['captcha_code']  ){
            throw new exception("Captcha does not match!");

        }


//        $query = "SHOW TABLE STATUS LIKE 'profiles'";
//        $result = mysqli_query($link,$query);
//        $result2 = mysqli_fetch_array($result);
//        foreach($result2 as $row)
//            echo $new_id = $row[10];

        $file_ext = substr($file_name, strripos($file_name, '.')); // Extract extension
        if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
            throw new exception("Only jpg, jpeg, png and gif format images are allowed to upload.");

        }else{
            $f1 = $_SESSION['captcha_code'].$file_name;
            move_uploaded_file($file_tmp_name,"$upload_dir".$f1) or die("<span style='color: red'>Upload Failed!</span><br>");
			//all input field session Destroy
			unset($_SESSION['user_fname']);
			unset($_SESSION['user_lname']);
			unset($_SESSION['user_name']);
			unset($_SESSION['user_password']);
			unset($_SESSION['user_email_c']);
			unset($_SESSION['user_mobile_n']);
			unset($_SESSION['user_address']);
			unset($_SESSION['user_zipcode_u']);
			unset($_SESSION['user_city_u']);
			unset($_SESSION['user_district']);


			//ends
            $query ="INSERT INTO `lostnfound`.`profiles` (`id`, `user_id`, `first_name`, `last_name`, `password`,
 `mobile_number`, `address`, `zip_code`, `city`, `district`, `status`, `created`, `created_by`, `modified`, `modified_by`,
  `deleted_at`, `profile_picture`) VALUES (NULL, '".$user_id."', '".$user_fname."', '".$user_lname."', '".$user_password."',
   '".$user_mobile."', '".$user_address."', '".$user_zipcode."',
  '".$user_city."', '".$user_district."', '".$status."', '".$created_date."', '".$created_by."', '', '', CURRENT_TIMESTAMP, '".$f1."')";


            $result = mysqli_query($link,$query);
            if($result){
                $success_message = "Data inserted successfully.";

            }else{
                throw new exception("Registration process faield");
            }


            $query2 = "INSERT INTO `lostnfound`.`users` (`id`, `username`, `email`, `password`, `is_admin`, `created`,
 `created_by`, `modified`, `modified_by`) VALUES (NULL, '".$user_name."', '".$user_email."', '".$user_password."', '0',
 '".$created_date."', '".$user_id."',
 '', '')";
            $result2 = mysqli_query($link,$query2);
            if($result2){
                $success_message = "successfully Registered. Please check your mail . Now login <a href='login.php'>Login</a>";

            }else{
                throw new exception("Registration process failed");
            }



            //Sending Email confirmation

            $to = $user_email;
            $subject = "Account confirmation";

            $message = "
                <html>
                <head>
                <title>Account confirmation</title>
                </head>
                <body>
                <p>Your account has been created successfully! </p>
                <table>
                <tr>
                <td>First name</td>
                <td>Last name</td>
                </tr>
                <tr>
                <th>$user_fname</th>
                <th>$user_lname</th>
                </tr>
                </table>
                </body>
                </html>
            ";

                // Always set content-type when sending HTML email
                            $headers = "MIME-Version: 1.0" . "\r\n";
                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



                            mail($to,$subject,$message,$headers);

        }

    }

    catch(Exception $e){

        $error_meassage = $e->getMessage();



    }

}

?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>USER SIGN UP <small>Fill up the form</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">
            <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-sign-in"></i> Sign up</div>
                <div class="panel-body">

                    <?php
                    if(isset($error_meassage))
                    {
                        echo '<div class="alert alert-danger">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Ops ! &nbsp;</strong>';
                        echo $error_meassage."<br>";
                        echo '</div>';
                    }

                    if(isset($success_message))
                    {
                        echo '<div class="alert alert-success">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Nice! &nbsp;</strong>';
                        echo $success_message."<br>";
                        echo '</div>';
                    }
                    ?>

                    <form action="" method="post" enctype="multipart/form-data">



<!--                        <div class="form-group">-->
<!--                            <label class="control-label col-md-2" for="userid">User id:</label>-->
<!--                            <div class="col-md-10">-->
<!--                                <input type="text" class="form-control" id="userid" name="userid" placeholder="user id">-->
<!--                            </div>-->
<!--                        </div>-->

                        <div class="form-group">
                            <label class="control-label col-md-2" for="firstName">First name</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="firstName" name="user_first_name" placeholder="First name" <?php echo $opt_user_fname; unset($opt_user_fname); ?>>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="lastName">Last name</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="lastName" name="user_last_name" placeholder="Last name" <?php echo $opt_user_lname;  unset($opt_user_lname);?>>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="username">Username:</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="userid" name="username" placeholder="username"  <?php echo $opt_user_name;  unset($opt_user_name);?>>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="userpassword">Password</label>
                            <div class="col-md-10">
                                <input type="password" class="form-control" id="userpassword" name="user_password" placeholder="Password" <?php echo $opt_user_password;  unset($opt_user_password);?>>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="email">Email</label>
                            <div class="col-md-10">
                                <input type="email" class="form-control" id="email" name="user_email" placeholder="user@gmail.com"  <?php echo $opt_user_email;  unset($opt_user_email);?>>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="mobileNumber">Mobile</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="mobileNumber" name="user_mobile" placeholder="(880)1722645583"  <?php echo $opt_user_mobile;  unset($opt_user_mobile);?>>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="address">Address</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="address" name="user_address" placeholder="address"  <?php echo $opt_user_address;  unset($opt_user_address);?>>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="zipCode">Zip Code</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="zipCode" name="user_zipcode" placeholder="Zip code"  <?php echo $opt_user_zipcode;  unset($opt_user_zipcode);?>>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="city">City</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="city" name="user_city" placeholder="City" <?php echo $opt_user_city;  unset($opt_user_city);?>>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="district">District</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="district" name="user_district" placeholder="District" <?php echo $opt_user_district;  unset($opt_user_district);?>>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="profilePic">Profile</label>
                            <div class="col-md-10">
                                <input type="file" style="height: auto" class="form-control" id="profilePic" name="user_profile_pic" >
                            </div>
                        </div>



                        <div class="form-group">
                            <label class="control-label col-md-2" for="captcha">
                                <?php
                                $captcha ="";
                                for($i=0;$i<=4;$i++){


                                    $captcha .= chr(rand(97,122));


                                }

                                $_SESSION['captcha_code'] = $captcha;
                                echo "<span style='
                                        background: #000000 none repeat scroll 0 0;
                                        box-shadow: 0 1px 9px #000;
                                        color: white;
                                        font-size: 20px;
                                        padding: 5px 24px;'>$captcha</span>";
                                ?>
                            </label>
                            <div class="col-md-10">

                                <input type="text"  class="form-control" id="captcha" name="user_captcha" placeholder="Captcha code">
                            </div>
                        </div>


                        <div class="form-group">
                                <div class="col-md-offset-2 col-md-10">
                                    <button type="submit" name ="form1" class="btn btn-default"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Submit</button>
                                </div>
                            </div>


                    </form>

                </div>
            </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
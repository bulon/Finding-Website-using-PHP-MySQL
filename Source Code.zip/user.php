<?php include_once 'lib/app.php';?>
<?php include_once 'userlogincheck.php';?>

<?php

if(isset($_SESSION['user_id'])){

    $id = $_SESSION['user_id'];
    $query = "SELECT * FROM profiles WHERE user_id = $id";
    $result = mysqli_query($link,$query);
    $row = mysqli_fetch_assoc($result);

}
?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">

            </div>
<!--
            <div class="row">
                <div class="col-md-12">
                    <div class="list-group text-center">
                        <a class="list-group-item " href="#"><i class="fa fa-home fa-fw"></i>&nbsp; User profile</a>
                        <a class="list-group-item" href="#"><i class="fa fa-cog fa-fw"></i>&nbsp; Edit profile</a>
                        <a class="list-group-item" href="#"><i class="fa fa-cog fa-fw"></i>&nbsp; Settings</a>
                        <a class="list-group-item" href="#"><i class="fa fa-book fa-fw"></i>&nbsp; Product registration</a>
                        <a class="list-group-item" href="#"><i class="fa fa-pencil fa-fw"></i>&nbsp; Existing Products</a>
                    </div>

                </div>
            </div>


-->

            <div class="col-lg-12 col-sm-12" style="padding-left: 0px;padding-right: 0px">
                <div class="card hovercard">
                    <div class="card-background">
                        <img class="card-bkimg" alt="" src="assets/user/uploads/pattern-swirls-ipad-background.jpg">
                        <!-- http://lorempixel.com/850/280/people/9/ -->
                    </div>
                    <div class="useravatar">
                        <img alt="" src="assets/user/uploads/<?php echo $row['profile_picture'];?>">
                    </div>
                    <div class="card-info"> <span class="card-title"><?php echo $row['first_name'].' '.$row['last_name'];?></span>

                    </div>
                </div>

            </div>


    </div>
<br>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">
            <div class="panel panel-default">

                <div class="panel-body text-center">

                    <div class="col-md-3">
                        <a href="productadd.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-shopping-cart"></a><p>Add product</p>
                    </div>
                    <div class="col-md-3">
                        <a href="productmanage.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-pencil"></a><p>Manage product</p>
                    </div>
                    <div class="col-md-3">
                        <a href="userprofileedit.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-user"></a><p>Manage profile</p>
                    </div>
                    <div class="col-md-3">
                        <a href="usersug.php" class="btn btn-default btn-lg-custom"><span style="font-size:30px" class="glyphicon glyphicon-comment"></a><p>Send a suggestion</p>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
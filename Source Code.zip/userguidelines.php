<?php include_once 'lib/app.php';?>
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Dashboard <small>statistics & reports</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <?php
            $query = "SELECT * FROM guidelines ";
            $result = mysqli_query($link,$query);
            $row = mysqli_fetch_array($result);

            ?>

            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title">
                             <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"><span>
                                     <span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> About the documentation
                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <div class="well">
                                <p><span style="color: #122b40" class="glyphicon glyphicon-hand-right"></span> &nbsp;&nbsp;<?php echo $row['title'];?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingTwo">
                        <h4 class="panel-title">
                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> User manual
                            </a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                        <div class="panel-body">

                                <div class="well">
                                    <p><span style="color: #122b40" class="glyphicon glyphicon-hand-right"></span> &nbsp;&nbsp;<?php echo substr($row['description'],0,200)?></p>
                                </div>
                                <div class="well">
                                    <p><span style="color: #122b40" class="glyphicon glyphicon-hand-right"></span> &nbsp;&nbsp;<?php echo $row['description'];?></p>
                                </div>
                                <div class="well">
                                    <p><span style="color: #122b40" class="glyphicon glyphicon-hand-right"></span> &nbsp;&nbsp;<?php echo substr($row['description'],0,300)?></p>
                                </div>
                                <div class="well">
                                    <p><span style="color: #122b40" class="glyphicon glyphicon-hand-right"></span> &nbsp;&nbsp;<?php echo substr($row['description'],0,350)?></p>
                                </div>

                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingThree">
                        <h4 class="panel-title">
                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                <span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> See a example
                            </a>
                        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                        <div class="panel-body">
                             <a data-toggle="modal" data-target="#myModal" href=""> <img src="assets/user/images/<?php echo $row['example'];?>" alt="Tutorial example" class="img-thumbnail" width="500" ></a>

                            <!-- Modal -->
                            <div class="modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 style="color:red;"><span class="glyphicon glyphicon-file"></span> Snapshot</h4>
                                        </div>
                                        <div class="modal-body">
                                            <img src="assets/user/images/<?php echo $row['example'];?>" alt="Tutorial example" class="img-thumbnail img-responsive"  >

                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-default btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
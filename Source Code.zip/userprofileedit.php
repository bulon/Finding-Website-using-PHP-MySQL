<?php include_once 'lib/app.php';?>
<?php include_once 'userlogincheck.php';?>
<?php
if(isset($_POST['form'])){

$user_fname = test_input($_POST['user_first_name']);
$user_lname = test_input($_POST['user_last_name']);
$user_password = md5(test_input($_POST['user_password']));
$user_mobile = test_input($_POST['user_mobile']);
$user_address = test_input($_POST['user_address']);
$user_zipcode = test_input($_POST['user_zipcode']);
$user_city = test_input($_POST['user_city']);
$user_district = test_input($_POST['user_district']);
$file_name = $_FILES['user_profile_pic']['name'];
$file_tmp_name = $_FILES['user_profile_pic']['tmp_name'];
$file_size = $_FILES['user_profile_pic']['size'];
$upload_dir = "assets/user/uploads/";

    $modified_date = date("d-m-y h:i:s");

if(empty($file_name)){

    $query = "UPDATE `lostnfound`.`profiles` SET `first_name` = '".$user_fname."', `last_name` = '".$user_lname."', `password` = '".$user_password."', `mobile_number` = '".$user_mobile."', `address` = '".$user_address."', `zip_code` = '".$user_zipcode."', `city` = '".$user_city."', `district` = '".$user_district."' WHERE `profiles`.`user_id` = '$_SESSION[user_id]'";
    $result = mysqli_query($link,$query);

    $query = "UPDATE `lostnfound`.`users` SET `password` = '".$user_password."', `modified` = '".$modified_date."', `modified_by` = '$_SESSION[user_id]' WHERE `users`.`created_by` = '$_SESSION[user_id]'";
    $result = mysqli_query($link,$query);

}else{




    $file_ext = substr($file_name, strripos($file_name, '.')); // Extract extension

    if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
        echo "Only jpg, jpeg, png and gif format images are allowed to upload.";

    }
    else{


        $query = "SELECT profile_picture FROM profiles WHERE user_id = '$_SESSION[user_id]' ";
        $result = mysqli_query($link,$query);
        $row = mysqli_fetch_array($result);
        $real_path = "assets/user/uploads/".$row['profile_picture'];
        unlink($real_path);
        $captcha ="";
        for($i=0;$i<=10;$i++){


            $captcha .= chr(rand(97,122));


        }
        $f1 = $captcha.$file_name;
        move_uploaded_file($file_tmp_name,"$upload_dir".$f1) or die("<span style='color: red'>Upload Failed!</span><br>");
        $query = "UPDATE `lostnfound`.`profiles` SET `first_name` = '".$user_fname."', `last_name` = '".$user_lname."', `password` = '".$user_password."', `mobile_number` = '".$user_mobile."', `address` = '".$user_address."', `zip_code` = '".$user_zipcode."', `city` = '".$user_city."', `district` = '".$user_district."',`profile_picture`='".$f1."' WHERE `profiles`.`user_id` = '$_SESSION[user_id]'";
        $result = mysqli_query($link,$query);

        $query = "UPDATE `lostnfound`.`users` SET `password` = '".$user_password."', `modified` = '".$modified_date."', `modified_by` = '$_SESSION[user_id]' WHERE `users`.`created_by` = '$_SESSION[user_id]'";
        $result = mysqli_query($link,$query);


    }

}
}

?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>User Profile <small>Manage your user profile</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <table class="table table-bordered">
                <thead>
                <tr>

                    <th>First name</th>
                    <th>Last name</th>
                    <th>Mobile</th>
                    <th>Address</th>
                    <th>Zip code</th>
                    <th>City</th>
                    <th>District</th>
                    <th>Pic</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php

                    $query ="select * FROM profiles WHERE user_id='$_SESSION[user_id]' ";
                    $result = mysqli_query($link,$query);

                    while($row = mysqli_fetch_array($result)){


                        ?>

                        <tr>

                            <td><?php echo $row['first_name'];?></td>
                            <td><?php echo $row['last_name'];?></td>
                            <td><?php echo $row['mobile_number'];?></td>
                            <td><?php echo $row['address'];?></td>
                            <td><?php echo $row['zip_code'];?></td>
                            <td><?php echo $row['city'];?></td>
                            <td><?php echo $row['district'];?></td>
                            <td><img  class="img-thumbnail" width="50" height="50" src="assets/user/uploads/<?php echo $row['profile_picture'];?>"</td>
                            <td><a data-toggle="modal" href="#basic" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-pencil"></span> Edit</a></td>


                        </tr>



                <?php
                    }

                ?>


                </tbody>
            </table>

            <div class="modal fade" id="basic" tabindex="-1" role="basic" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <h4 class="modal-title">Update your profile</h4>
                        </div>
                        <div class="modal-body">

                            <div class="panel panel-default">
                                <?php
                                $query ="select * FROM profiles WHERE user_id='$_SESSION[user_id]' ";
                                $result = mysqli_query($link,$query);
                                $row = mysqli_fetch_array($result);
                                ?>
                                <div class="panel-heading"><span class="glyphicon glyphicon-pencil"></span> Update</div>
                                <div class="panel-body">

                                    <form action="userprofileedit.php" method="post" enctype="multipart/form-data">

                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="firstName">F name</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" value="<?php echo $row['first_name'];?>" id="firstName" name="user_first_name" placeholder="First name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="lastName">L name</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" value="<?php echo $row['last_name'];?>" id="lastName" name="user_last_name" placeholder="Last name">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="userpassword">Password</label>
                                            <div class="col-md-10">
                                                <input type="password" class="form-control"  id="userpassword" name="user_password" placeholder="Password">
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="mobileNumber">Mobile</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" value="<?php echo $row['mobile_number'];?>" id="mobileNumber" name="user_mobile" placeholder="(880)1722645583">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="address">Address</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" value="<?php echo $row['address'];?>" id="address" name="user_address" placeholder="address">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label  col-md-2" for="zipCode">Zip Code</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control"  value="<?php echo $row['zip_code'];?>"id="zipCode" name="user_zipcode" placeholder="Zip code">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="city">City</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" value="<?php echo $row['city'];?>" id="city" name="user_city" placeholder="City">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="district">District</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" value="<?php echo $row['district'];?>" id="district" name="user_district" placeholder="District">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-md-2" for="profilePic">Profile Picture</label>
                                            <div class="col-md-10">
                                                <input type="file" style="height: auto" class="form-control" id="profilePic" name="user_profile_pic" >
                                            </div>
                                        </div>



                                        <div class="form-group">
                                            <div class="col-md-offset-2 col-md-10">
                                                <button type="submit" name ="form" class="btn btn-default"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Update</button>
                                            </div>
                                        </div>


                                    </form>

                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn default" data-dismiss="modal"> <span class="glyphicon glyphicon-remove"></span> Close</button>

                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
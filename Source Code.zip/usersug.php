<?php include_once 'lib/app.php';?>
<?php include_once 'userlogincheck.php';?>
<?php

if(isset($_POST['form1']))
{
        $err =0;
         $message ='';
    try {
        $sub = $_POST['sug_subject'];
        $msg = $_POST['sug_msg'];
        $user_id = $_SESSION['user_id'];


        if(empty($sub)) {
            $err =1;
            $message ="<p>Please enter message sub!</p>";

        }

        if(empty($msg)) {
            $err =1;
            $message .="<p>Please enter message body!</p>";
        }

        if($err == 1){
            throw new exception($message);
        }



        $query ="INSERT INTO `lostnfound`.`suggestions` (`id`, `user_id`, `subject`, `message`) VALUES (NULL, '".$user_id."', '".$sub."', '".$msg."')";
        $result = mysqli_query($link,$query);

        if($result){
            $success_message ="Message Sent! Thank you for your feedback";


        }else{
            throw new exception("Message sending failed. Try again latter!");
        }











    }

    catch(Exception $e) {
        $error_message = $e->getMessage();
    }

}

?>

<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Suggestion <small>Have you any suggestion?</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <div class="panel panel-default">
                <div class="panel-heading"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> Suggestion</div>
                <div class="panel-body">

                    <?php
                    if(isset($error_message))
                    {
                        echo '<div class="alert alert-danger">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Ops ! &nbsp;</strong>';
                        echo $error_message."<br>";
                        echo '</div>';
                    }

                    if(isset($success_message))
                    {
                        echo '<div class="alert alert-success">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Nice! &nbsp;</strong>';
                        echo $success_message."<br>";
                        echo '</div>';
                    }
                    ?>
                <form action="" method="post">

                        <div class="form-group">
                            <label class="control-label col-md-2" for="title">Subject</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="title" name="sug_subject" placeholder="">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="description">Suggestion</label>
                            <div class="col-md-10">
                                <textarea class="form-control" id="description" name="sug_msg" rows="8" placeholder=""> </textarea>
                            </div>
                        </div>




                        <div class="form-group">
                            <div class="col-md-offset-2 col-md-10">
                                <button type="submit" name ="form1" class="btn btn-default"><span class="glyphicon glyphicon-send" aria-hidden="true"></span> Submit</button>
                            </div>
                        </div>


                </form>

                </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
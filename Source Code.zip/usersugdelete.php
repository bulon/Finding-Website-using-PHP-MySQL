<?php include_once 'lib/app.php';?>
<?php include_once 'adminlogincheck.php';?>
<?php

if(isset($_REQUEST['id'])){

    $query = "DELETE FROM suggestions WHERE id= '$_REQUEST[id]'";
    $result = mysqli_query($link,$query);

    $success_message = "Successfully deleted";

    header("location:usersuggmanage.php?msg=$success_message");


}else{
    header("location:admin.php");
}

?>
<?php include_once 'lib/app.php';?>
<?php include_once 'adminlogincheck.php';?>

<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>User suggestions <small>Manage and show all users suggestions</small></h1>
            </div>


            <!-- END PAGE TITLE -->

        </div>
    </div>
    <!-- END PAGE HEAD -->
    <!-- BEGIN PAGE CONTENT -->
    <div class="page-content">
        <div class="container">

            <div class="panel panel-default">
                <div class="panel-heading"><span class="glyphicon glyphicon-comment"></span> All Suggestions</div>
                <div class="panel-body">
                    <?php

                    if(isset($_REQUEST['msg']))
                    {
                        echo '<div class="alert alert-success">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <strong>Nice! &nbsp;</strong>';
                        echo $_REQUEST['msg']."<br>";
                        echo '</div>';
                    }
                    ?>
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Sl</th>
                            <th>Subject</th>
                            <th>Suggestions</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>

<!--                        /* ===================== Pagination Code Starts ================== */-->
                        <?php
                        $adjacents = 7;




                        $query = "SELECT * FROM suggestions ORDER BY id DESC";
                        $result = mysqli_query($link,$query);

                        $total_pages = mysqli_num_rows($result);


                        $targetpage = $_SERVER['PHP_SELF'];   //your file name  (the name of this file)
                        $limit = 4;                                 //how many items to show per page
                        $page = @$_GET['page'];
                        if($page)
                        $start = ($page - 1) * $limit;          //first item to display on this page
                        else
                        $start = 0;

                        $query = "SELECT * FROM suggestions ORDER BY id DESC LIMIT $start, $limit";
                        $result = mysqli_query($link,$query);

//                        $statement = $db->prepare("SELECT * FROM tbl_post ORDER BY post_id DESC LIMIT $start, $limit");
//                        $statement->execute();
//                        $result = $statement->fetchAll(PDO::FETCH_ASSOC);


                        if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
                        $prev = $page - 1;                          //previous page is page - 1
                        $next = $page + 1;                          //next page is page + 1
                        $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
                        $lpm1 = $lastpage - 1;
                        $pagination = "";
                        if($lastpage > 1)
                        {
                        $pagination .= "<div class=\"pagination\">";
                            if ($page > 1)
                            $pagination.= "<a href=\"$targetpage?page=$prev\">&#171; previous</a>";
                            else
                            $pagination.= "<span class=\"disabled\">&#171; previous</span>";
                            if ($lastpage < 7 + ($adjacents * 2))   //not enough pages to bother breaking it up
                            {
                            for ($counter = 1; $counter <= $lastpage; $counter++)
                            {
                            if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                            else
                            $pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";
                            }
                            }
                            elseif($lastpage > 5 + ($adjacents * 2))    //enough pages to hide some
                            {
                            if($page < 1 + ($adjacents * 2))
                            {
                            for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                            {
                            if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                            else
                            $pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";
                            }
                            $pagination.= "...";
                            $pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
                            $pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";
                            }
                            elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
                            {
                            $pagination.= "<a href=\"$targetpage?page=1\">1</a>";
                            $pagination.= "<a href=\"$targetpage?page=2\">2</a>";
                            $pagination.= "...";
                            for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                            {
                            if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                            else
                            $pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";
                            }
                            $pagination.= "...";
                            $pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
                            $pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";
                            }
                            else
                            {
                            $pagination.= "<a href=\"$targetpage?page=1\">1</a>";
                            $pagination.= "<a href=\"$targetpage?page=2\">2</a>";
                            $pagination.= "...";
                            for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                            {
                            if ($counter == $page)
                            $pagination.= "<span class=\"current\">$counter</span>";
                            else
                            $pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";
                            }
                            }
                            }
                            if ($page < $counter - 1)
                            $pagination.= "<a href=\"$targetpage?page=$next\">next &#187;</a>";
                            else
                            $pagination.= "<span class=\"disabled\">next &#187;</span>";
                            $pagination.= "</div>\n";
                        }
                        /* ===================== Pagination Code Ends ================== */



                            $i=0;
                            while($row = mysqli_fetch_array($result)){
                                $i++;
                        ?>
                                <tr>
                                    <td><?php echo $i ;?></td>
                                    <td><?php echo $row['subject'] ;?></td>
                                    <td><?php echo $row['message'] ;?></td>
                                    <td><a class="btn btn-danger btn-sm" href="usersugdelete.php?id=<?php echo $row['id'];?>"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Delete</a></td>
                                </tr>

                        <?php
                            }

                        ?>

                        </tbody>
                    </table>
                    <div class="pagination">
                        <?php
                        echo $pagination;
                        ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
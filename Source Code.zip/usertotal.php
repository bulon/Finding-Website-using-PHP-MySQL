<?php include_once 'lib/app.php';?>
<?php include_once 'adminlogincheck.php';?>
<?php



    $query = "SELECT * FROM `users`";
    $result = mysqli_query($link,$query);

    $counter=0;
    while($row = mysqli_fetch_array($result)){
        $counter++;

    }

?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

    <?php include_once('page_menu.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
    <!-- BEGIN PAGE HEAD -->
    <div class="page-head">
        <div class="container">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">

            </div>





        </div>
        <br>
        <!-- END PAGE HEAD -->
        <!-- BEGIN PAGE CONTENT -->
        <div class="page-content">

            <div class="container">


                <div class="panel panel-default">
                    <?php



                    $query = "SELECT * FROM `users` WHERE is_admin =1";
                    $result = mysqli_query($link,$query);

                    $counter=0;
                    while($row = mysqli_fetch_array($result)){
                        $counter++;
                        $user_name = $row['username'];
                        $user_email = $row['email'];
                        $user_id = $row['created_by'];
                    }

                    ?>
                    <div class="panel-heading">Total Admin <span class="badge"><?php echo $counter;?></span></div>
                    <div class="panel-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Username</th>
                                <th>User id</th>
                                <th>User Email</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php

                            $query = "SELECT * FROM `users` WHERE is_admin =1";
                            $result = mysqli_query($link,$query);

                            while($row = mysqli_fetch_array($result)){
                                ?>
                                <tr>

                                    <td><?php echo $row['username'];?></td>
                                    <td><?php echo $row['created_by'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                </tr>


                            <?php

                            }

                            ?>
                            </tbody>
                        </table>

                    </div>

                </div>
                <div class="container">
                    
                </div>

                <div class="panel panel-default">
                    <?php



                    $query = "SELECT * FROM `users` WHERE is_admin =0";
                    $result = mysqli_query($link,$query);

                    $counter=0;
                    while($row = mysqli_fetch_array($result)){
                        $counter++;
                        $user_name = $row['username'];
                        $user_email = $row['email'];
                        $user_id = $row['created_by'];
                    }

                    ?>
                    <div class="panel-heading">Total Users <span class="badge"><?php echo $counter;?></span></div>
                    <div class="panel-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Username</th>
                                <th>User id</th>
                                <th>User Email</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>

                                <?php

                                $query = "SELECT * FROM `users` WHERE is_admin =0";
                                $result = mysqli_query($link,$query);

                                while($row = mysqli_fetch_array($result)){
                                ?>
                                <tr>

                                    <td><?php echo $row['username'];?></td>
                                    <td><?php echo $row['created_by'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                    <?php
                                    $query2 = "SELECT is_block FROM `users` WHERE is_admin =0 AND  created_by= '$row[created_by]'";
                                    $result2 = mysqli_query($link,$query2);
                                    $status = mysqli_fetch_array($result2);


                                    ?>
                                    <td>
                                        <?php
                                            if($status['is_block'] == 0){
                                                echo '<span style="color:#4db3a4" class="glyphicon glyphicon-ok" aria-hidden="true"></span>';
                                            }else{
                                                echo '<span style="color:red" class="glyphicon glyphicon-remove" aria-hidden="true"></span>';

                                            }

                                        ?>

                                    </td>

                                </tr>


                                <?php

                                }

                                ?>

                            </tbody>
                        </table>

                    </div>

                </div>




            </div>

        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
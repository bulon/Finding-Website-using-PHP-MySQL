<?php include_once 'lib/app.php';?>
<?php include_once 'adminlogincheck.php';?>
<?php

if(isset($_REQUEST['id'])){
    $id = $_REQUEST['id'];
    $query ="UPDATE `lostnfound`.`users` SET `is_block` = '0' WHERE `users`.`id` = $id";
    $result = mysqli_query($link,$query);
    if($result){
        $success_message = "Unblock success!";
    }
    header("location:userblock.php?msg=$success_message");

}else{
    header("location:admin.php");
}
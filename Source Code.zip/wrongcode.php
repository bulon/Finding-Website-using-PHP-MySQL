<?php include_once 'lib/app.php';ob_start();?>
<!---Page Head Begin--->
<?php include_once('page_head.php'); ?>
<!---Page Head End--->

<body>

<!---Page Header Begin--->
<div class="page-header">

    <?php include_once('page_header_top.php'); ?>

	<?php include_once('page_menu_u_user.php'); ?>

</div>

<!---End of Page Header--->


<!---Page Content Begin--->
<div class="page-container">
	<!-- BEGIN PAGE HEAD -->
	<div class="page-head">
		<div class="container">
			<!-- BEGIN PAGE TITLE -->
			
			<?php 
				
				if(isset($_SESSION['wrong_code'])){
					
					$error_meassage = "No match found , Try again! <a href='index.php'>Go home</a>"; 
					
				}else{
					header("location:index.php"); 
				}
				
				
			
			?>
			<div class="page-title">
				<h1> <small></small></h1>
			</div>


			<!-- END PAGE TITLE -->

		</div>
	</div>
	<!-- END PAGE HEAD -->
	<!-- BEGIN PAGE CONTENT -->
	<div class="page-content">
		<div class="container">
			<div class="jumbotron text-center">
				<?php 
					if(isset($error_meassage))
                    {
                        echo "<h2 style=\"color:red\">$error_meassage</h2>";
						 
                    }
					session_destroy();
				
				?>
			</div>
		</div>
	</div>
	<!-- END PAGE CONTENT -->
</div>
<!---Page Content End--->


<!---Page Footer Begin--->
<?php include_once('page_footer.php'); ?>
<!---Page Footer End--->
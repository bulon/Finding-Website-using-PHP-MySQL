<?php
define("MESSAGE_SUCCESS","Successful!");
define("MESSAGE_FAILED","Failed!");
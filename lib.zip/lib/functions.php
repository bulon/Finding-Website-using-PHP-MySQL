<?php

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function pdf_create($html, $filename, $paper, $orientation, $stream=TRUE)
{
    $dompdf = new DOMPDF();
    $dompdf->set_paper($paper,$orientation);
    $dompdf->load_html($html);
    $dompdf->render();
    $dompdf->stream($filename.".pdf");
}

function  unique_id_gen(){
    $uni_id = rand(10,99);

    $first = $uni_id;
    $chars_to_do = 6 - strlen($uni_id);
    for ($i = 1; $i <= $chars_to_do; $i++)
    {
        $first .= chr(rand(48,57));

    }

    return $first;

}



function debug($data){
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}